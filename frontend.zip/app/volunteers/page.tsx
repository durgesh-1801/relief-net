"use client"

import { AppShell } from "@/components/app-shell"
import { VolunteerRegistrationForm } from "@/components/volunteer-registration-form"
import { VolunteerList } from "@/components/volunteer-list"
import { StatsCard } from "@/components/stats-card"
import { mockVolunteers } from "@/lib/data"
import { Users, UserCheck, Clock, Shield } from "lucide-react"

export default function VolunteersPage() {
  const stats = {
    total: mockVolunteers.length,
    available: mockVolunteers.filter((v) => v.available).length,
    onMission: mockVolunteers.filter((v) => !v.available).length,
  }

  return (
    <AppShell>
      <div className="max-w-7xl mx-auto">
        {/* Page header */}
        <div className="mb-8">
          <div className="flex items-center gap-2 text-sm text-muted-foreground mb-2">
            <span>Team</span>
            <span>/</span>
            <span className="text-foreground">Volunteers</span>
          </div>
          <h1 className="text-2xl sm:text-3xl font-bold text-foreground tracking-tight">
            Volunteer Management
          </h1>
          <p className="text-muted-foreground mt-1">
            Register as a volunteer or manage the current response team roster
          </p>
        </div>

        {/* Stats */}
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 mb-8">
          <StatsCard
            title="Total Volunteers"
            value={stats.total}
            icon={Users}
            variant="default"
            description="Registered responders"
          />
          <StatsCard
            title="Available Now"
            value={stats.available}
            icon={UserCheck}
            variant="success"
            description="Ready for assignment"
          />
          <StatsCard
            title="On Active Duty"
            value={stats.onMission}
            icon={Shield}
            variant="warning"
            description="Currently deployed"
          />
        </div>

        {/* Main content */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <VolunteerRegistrationForm />
          <VolunteerList volunteers={mockVolunteers} />
        </div>
      </div>
    </AppShell>
  )
}
